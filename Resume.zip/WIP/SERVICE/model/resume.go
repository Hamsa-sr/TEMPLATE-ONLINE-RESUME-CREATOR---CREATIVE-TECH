package model

import (
	"go.mongodb.org/mongo-driver/bson/primitive"
)

type Achievements struct {
	Title       string
	Description string
}
type Experience struct {
	Title     string
	Company   string
	Location  string
	StartDate string
	EndDate   string
}
type Education struct {
	SchoolCollege string
	Percentage    string
	StartDate     string
	EndDate       string
}
type Project struct {
	ProjectName string
	ProjectLink string
	Description string
}
type Skills struct {
	Skills string
}
type Resume struct {
	ID           primitive.ObjectID
	Firstname    string
	Middlename   string
	Lastname     string
	Photo        string
	Designation  string
	LinkedInLink string
	Email        string
	PhoneNumber  string
	Achievements []Achievements
	Experience   []Experience
	Education    []Education
	Project      []Project
	Skills       []Skills
}
