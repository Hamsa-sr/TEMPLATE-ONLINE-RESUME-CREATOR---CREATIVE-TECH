package routes

import (
	getCollection "SERVICE/collection"
	database "SERVICE/database"
	model "SERVICE/model"
	"context"
	"log"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

func CreateResume(c *gin.Context) {
	var DB = database.ConnectDB()
	var postCollection = getCollection.GetCollection(DB, "Posts")
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	resume := new(model.Resume)
	defer cancel()

	if err := c.BindJSON(&resume); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"message": err})
		log.Fatal(err)
		return
	}

	postPayload := model.Resume{
		ID:           primitive.NewObjectID(),
		Firstname:    resume.Firstname,
		Middlename:   resume.Middlename,
		Lastname:     resume.Lastname,
		Photo:        resume.Photo,
		Designation:  resume.Designation,
		LinkedInLink: resume.LinkedInLink,
		Email:        resume.Email,
		PhoneNumber:  resume.PhoneNumber,
		Achievements: resume.Achievements,
		Experience:   resume.Experience,
		Project:      resume.Project,
		Skills:       resume.Skills,
	}

	result, err := postCollection.InsertOne(ctx, postPayload)

	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"message": err})
		return
	}

	c.JSON(http.StatusCreated, gin.H{"message": "Posted successfully", "Data": map[string]interface{}{"data": result}})
}
